A Pen created at CodePen.io. You can find this one at https://codepen.io/digistate/pen/MvapbE.

 This sample is the tips for slick slider including YouTube, Vimeo and HTML5 video  player.
Each video plays automatically when the video slide has shown. And the slider fits the browser width.